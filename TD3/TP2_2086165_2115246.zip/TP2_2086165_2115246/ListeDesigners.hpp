﻿#pragma once
#include "Designer.hpp"

struct ListeDesigners
{
	unsigned nElements;
	unsigned capacite;
	Designer** elements;
};
