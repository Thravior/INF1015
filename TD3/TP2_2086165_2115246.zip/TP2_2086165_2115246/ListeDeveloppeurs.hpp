﻿/**
* Programme qui cree une classe d'une liste de developpeur.
* \file   ListeDeveloppeurs.hpp
* \author Laurie Bedard-Cote (2086165) et Mathias Gagnon (2115246)
* \date  5 octobre 2021
* \cree  23 septembre 2021
* \Programme qui cree une classe d'une liste de developpeur. 
* \Cette classe permettera d'ajouter ou de retirer des developpeur à la liste.
*/

#pragma once
#include "Developpeur.hpp"
#include <iostream>
#include <fstream>
#include "cppitertools/range.hpp"

using namespace iter;
using namespace std;

class ListeDeveloppeurs
{
public:
	void afficher();
	void ajouterDeveloppeur(Developpeur* developpeur);
	void retirerDeveloppeur(Developpeur*);
	
	ListeDeveloppeurs();
	~ListeDeveloppeurs();
	
private:	

	unsigned		nElements;
	unsigned		capacite;
	Developpeur**	elements;
	
	void augmenterCapacite();
};

ListeDeveloppeurs::ListeDeveloppeurs()
{
	nElements = 0;
	capacite  = 0;
	elements  = nullptr;
}

ListeDeveloppeurs:: ~ListeDeveloppeurs()
{
	delete[] elements;
	elements = nullptr;
}

void ListeDeveloppeurs::afficher()
{
	for ([[maybe_unused]] int i : iter::range(nElements)) {
		elements[i]->afficherDeveloppeur();
	}
}


void ListeDeveloppeurs::augmenterCapacite()
{
	unsigned nouvellecapacite = max(2 * capacite, capacite + 1);

	Developpeur** ptrDeveloppeur;
	ptrDeveloppeur = new Developpeur* [nouvellecapacite];
	

	for (int index : range(int(nElements))) {
		ptrDeveloppeur[index] = elements[index];
	}

	delete[] elements;

	capacite = nouvellecapacite;
	elements = ptrDeveloppeur;
}

void ListeDeveloppeurs::ajouterDeveloppeur(Developpeur* ptrDeveloppeur) 
{
	if (capacite == nElements) {
		augmenterCapacite();
	}

	bool estPresent = false;

	for (int index : range(int(nElements))) {
		if (elements[index]->getNomDeveloppeur() == ptrDeveloppeur->getNomDeveloppeur()) {
			estPresent = true;
			break;
		}
	}

	if (!estPresent) {
		elements[nElements] = ptrDeveloppeur;
		nElements += 1;
	}

}

void ListeDeveloppeurs::retirerDeveloppeur(Developpeur* ptrDeveloppeur) 
{
	for (int index : range(int(nElements))) {
		if (elements[index] == ptrDeveloppeur) {
			elements[index]			= elements[nElements - 1];
			elements[nElements - 1] = nullptr;
		}
	}

	nElements--;
}
