﻿/**
* Programme repondant aux enonces du TP2 partie 1.
* \file   main.cpp
* \author Laurie Bedard-Cote (2086165) et Mathias Gagnon (2115246)
* \date  5 octobre 2021
* \cree  23 septembre 2021
* \Programme qui, à partir d'un fichier binaire, affiche les différents
* \noms de jeux, leur année de sortie ainsi que les différents designers 
* \et leurs informations personelles. Le tout ce fait en 
* \procédant par allocation dynamique.
*/



#include "Jeu.hpp"
#include "ListeDeveloppeurs.hpp"
#include <iostream>
#include <fstream>
#include "cppitertools/range.hpp"
#include "gsl/span"
#include "bibliotheque_cours.hpp"
#include "verification_allocation.hpp"
#include "debogage_memoire.hpp"  //NOTE: Incompatible avec le "placement new", ne pas utiliser cette entête si vous utilisez ce type de "new" dans les lignes qui suivent cette inclusion.

using namespace std;
using namespace iter;
using namespace gsl;

#pragma region "Fonctions de base pour vous aider"
typedef uint8_t UInt8;
typedef uint16_t UInt16;
UInt8 lireUint8(istream& fichier)
{
	UInt8 valeur = 0;
	fichier.read((char*)&valeur, sizeof(valeur));
	return valeur;
}
UInt16 lireUint16(istream& fichier)
{
	UInt16 valeur = 0;
	fichier.read((char*)&valeur, sizeof(valeur));
	return valeur;
}
string lireString(istream& fichier)
{
	string texte;
	texte.resize(lireUint16(fichier));
	fichier.read((char*)&texte[0], streamsize(sizeof(texte[0])) * texte.length());
	return texte;
}
gsl::span<Jeu*> spanListeJeux(const ListeJeux& liste)
{
	return gsl::span(liste.elements, liste.nElements);
}
gsl::span<Designer*> spanListeDesigners(const ListeDesigners& liste)
{
	return gsl::span(liste.elements, liste.nElements);
}
#pragma endregion


Designer* trouverDesigner(const ListeJeux& listeJeux, string& nomDesigner) {
	for (Jeu* jeu : spanListeJeux(listeJeux)) {
		for (Designer* designer : spanListeDesigners(jeu->designers)) {
			if (nomDesigner == designer->nom) {
				return designer;
			}
		}
	}
	return nullptr;
}


Designer* lireDesigner(istream& fichier, ListeJeux& listeJeu)
{
	Designer designer = {}; // On initialise une structure vide de type Designer.
	designer.nom			=  lireString(fichier);
	designer.anneeNaissance	=  lireUint16(fichier);
	designer.pays			=  lireString(fichier);

	Designer* ptrDesigner;
	ptrDesigner = trouverDesigner(listeJeu, designer.nom);

	if (ptrDesigner == nullptr) {
		ptrDesigner = new Designer{ designer };
		
		// Affichage de confirmation d'allocation en memoire
		cout << designer.nom << " memoire allouee" << endl;
	}

	return ptrDesigner;
}


void augmenterListeJeu(ListeJeux& listeJeux)
{
	unsigned nouvellecapacite = max(2 * listeJeux.capacite, listeJeux.capacite + 1);

	Jeu** ptrJeu;
	ptrJeu = new Jeu* [nouvellecapacite];

	for (int index : range(int(listeJeux.nElements))) {
		ptrJeu[index] = listeJeux.elements[index];
	}

	delete[] listeJeux.elements;

	listeJeux.capacite = nouvellecapacite;
	listeJeux.elements = ptrJeu;
}


void ajoutJeu(ListeJeux& listeJeux, Jeu* ptrjeu)
{
	if (listeJeux.capacite == listeJeux.nElements) {
		augmenterListeJeu(listeJeux);
	}

	listeJeux.elements[listeJeux.nElements] = ptrjeu;
	listeJeux.nElements += 1;
}


void enleverJeu(ListeJeux& listeJeux, Jeu* ptrJeu)
{
	for (int index : range(int(listeJeux.nElements))) {
		if (listeJeux.elements[index] == ptrJeu) {
			listeJeux.elements[index]					= listeJeux.elements[listeJeux.nElements - 1];
			listeJeux.elements[listeJeux.nElements - 1] = nullptr;
		}
	}

	listeJeux.nElements--;
}


Jeu* lireJeu(istream& fichier, ListeJeux& listeJeu)
{
	Jeu jeu = {}; // On initialise une structure vide de type Jeu
	jeu.titre				= lireString(fichier);
	jeu.anneeSortie			= lireUint16(fichier);
	jeu.developpeur			= lireString(fichier);
	jeu.designers.nElements = lireUint8(fichier);
	// Rendu ici, les champs précédents de la structure jeu sont remplis avec la
	// bonne information.

	Jeu* ptrJeu;
	ptrJeu						= new Jeu{jeu};
	Designer** ptrDesigner		= new Designer* [ptrJeu->designers.nElements];
	ptrJeu->designers.elements	= ptrDesigner;

	// Affichage de confirmation d'allocation en memoire
	cout << jeu.titre << " memoire allouee" << endl;

	for (int i : iter::range(jeu.designers.nElements)) {
		Designer* ptr					= lireDesigner(fichier, listeJeu);
		ptrJeu->designers.elements[i]	= ptr;
		
		ajoutJeu(ptr->listeJeuxParticipes, ptrJeu);
	}

	return ptrJeu;
}


ListeJeux creerListeJeux(const string& nomFichier)
{
	ifstream fichier(nomFichier, ios::binary);
	fichier.exceptions(ios::failbit);
	int nElements		= lireUint16(fichier);
	ListeJeux listeJeux = {};

	for ([[maybe_unused]] int i : iter::range(nElements))
	{
		Jeu* ptr = lireJeu(fichier, listeJeux);
		ajoutJeu(listeJeux, ptr);
	}

	return listeJeux;
}


void detruireDesigner(Designer*& designer)
{
	cout << designer->nom << " détruit \n";
	delete[] designer->listeJeuxParticipes.elements;
	designer->listeJeuxParticipes.elements = nullptr;
	
	delete designer;
	designer = nullptr;
}


bool participationDesigner(Designer* designer)
{
	return (designer->listeJeuxParticipes.nElements > 0);
}


void detruireJeu(Jeu*& jeu)
{
	for (int i : range(jeu->designers.nElements)) {
		enleverJeu(jeu->designers.elements[i]->listeJeuxParticipes, jeu);
		
		if (!participationDesigner(jeu->designers.elements[i])) {
			detruireDesigner(jeu->designers.elements[i]);
		}
	}

	// Affichage de confirmation de libération de la memoire
	cout << jeu->titre << " detruit" << endl;
	delete[] jeu->designers.elements;
	jeu->designers.elements = nullptr;
	
	delete jeu;
	jeu = nullptr;
}


void detruireListeJeux(ListeJeux listeJeux)
{
	for (Jeu* element : spanListeJeux(listeJeux)) {
		detruireJeu(element);
	}

	delete[] listeJeux.elements;
	listeJeux.elements = nullptr;
}


void afficherDesigner(const Designer& d)
{
	cout << "\t" << d.nom << ", " << d.anneeNaissance << ", " << d.pays
		<< endl;
}


void afficherJeu(const Jeu& j)
{
	cout << j.titre << endl << j.anneeSortie << endl << j.developpeur << endl;
	
	for (unsigned i : range(j.designers.nElements)) {
		afficherDesigner(*j.designers.elements[i]);
	}
}

void afficherListeJeux(const ListeJeux& listeJeux)
{
	for (Jeu* element : spanListeJeux(listeJeux)) {
		afficherJeu(*element);
		cout << "\n\n";
	}
}




int main([[maybe_unused]] int argc, [[maybe_unused]] char** argv)
{
#pragma region "Bibliothèque du cours"
	// Permet sous Windows les "ANSI escape code" pour changer de couleur
	// https://en.wikipedia.org/wiki/ANSI_escape_code ; les consoles Linux/Mac
	// les supportent normalement par défaut.
	bibliotheque_cours::activerCouleursAnsi();
#pragma endregion

	ListeJeux listeCompleteJeux = creerListeJeux("jeux.bin");
	
	static const string ligneSeparation = "\n\033[35m════════════════════════════════════════\033[0m\n";
	cout << ligneSeparation << endl;
	cout << "Premier jeu de la liste :" << endl;
	afficherJeu(*listeCompleteJeux.elements[0]); 
	cout << ligneSeparation << endl;
	
	afficherListeJeux(listeCompleteJeux);
	
	// Test de la classe Developpeur & ListeDeveloppeurs
	
	cout << "\n*****************************" << endl;
	
	Developpeur nintendo = Developpeur("Nintendo");
	Developpeur sega = Developpeur("Sega");


	nintendo.mettreListeAJour(listeCompleteJeux);
	sega.mettreListeAJour(listeCompleteJeux);

	ListeDeveloppeurs listeDeveloppeurs = ListeDeveloppeurs();
	listeDeveloppeurs.ajouterDeveloppeur(&nintendo);
	listeDeveloppeurs.ajouterDeveloppeur(&sega);

	listeDeveloppeurs.afficher();

	cout << "*****************************  \n" << endl;

	listeDeveloppeurs.retirerDeveloppeur(&nintendo);
	listeDeveloppeurs.afficher();


	detruireListeJeux(listeCompleteJeux);
}
