﻿/**
* Programme qui cree un classe de developpeur.
* \file   Developpeur.hpp
* \author Laurie Bedard-Cote (2086165) et Mathias Gagnon (2115246)
* \date  5 octobre 2021
* \cree  23 septembre 2021
* \Programme qui cree un classe de developpeur. Cette classe 
* \permettera de mettre à jour la liste de jeu d'un developpeur
*/

#pragma once
#include "ListeJeux.hpp"
#include "Jeu.hpp"
#include <string>
#include <iostream>



class Developpeur
{
public:
	const std::string getNomDeveloppeur();
	unsigned          getNombreJeu(const ListeJeux);
	
	void mettreListeAJour(ListeJeux);
	void afficherDeveloppeur();

	Developpeur();
	Developpeur(const std::string& nom);
	Developpeur(const std::string& nom, ListeJeux);
	~Developpeur();
	
private:
	std::pair<std::string, ListeJeux> paireNomJeux_;
};

Developpeur::Developpeur() 
{
	paireNomJeux_ = std::make_pair("", ListeJeux{});
}

Developpeur::Developpeur(const std::string& nom)
{
	paireNomJeux_ = std::make_pair(nom, ListeJeux{});
}

Developpeur::Developpeur(const std::string& nom, ListeJeux listeJeux)
{
	paireNomJeux_ = std::make_pair(nom, ListeJeux{});
	mettreListeAJour(listeJeux);
}

Developpeur::~Developpeur()
{
	delete[] paireNomJeux_.second.elements;
}



unsigned Developpeur::getNombreJeu(const ListeJeux listeJeux) 
{
	unsigned compteur = 0;
	for (unsigned i = 0; i < listeJeux.nElements; i++) {
		if (listeJeux.elements[i]->developpeur == paireNomJeux_.first) {
			compteur++;
		}
	}
	return compteur;
}

void Developpeur::mettreListeAJour(const ListeJeux listeJeux) 
{
	ListeJeux listeJeuxParticipe = {};
	listeJeuxParticipe.capacite  = getNombreJeu(listeJeux);

	Jeu** ptrJeu;
	ptrJeu = new Jeu * [listeJeuxParticipe.capacite];
	listeJeuxParticipe.elements = ptrJeu;

	for (unsigned i = 0 ; i < listeJeux.nElements; ++i) {
		if (listeJeux.elements[i]->developpeur == paireNomJeux_.first){
			listeJeuxParticipe.elements[listeJeuxParticipe.nElements] = listeJeux.elements[i];
			listeJeuxParticipe.nElements++;
		}
	}
	paireNomJeux_.second = listeJeuxParticipe;
}



const std::string Developpeur::getNomDeveloppeur() 
{
	return paireNomJeux_.first;
}

void Developpeur::afficherDeveloppeur() 
{
	std::cout << paireNomJeux_.first << std::endl;
	for (unsigned i = 0; i < paireNomJeux_.second.nElements; i++) {
		std::cout << '\t' << paireNomJeux_.second.elements[i]->titre << std::endl;
	}
}